jQuery(document).ready(function($){
	
	var _this = {


		typeBtn: $(".typetBtn"),
		form: $("#encryption_form"),
		result: $("#encryption_result"),



		chooseType: function(){
			_this.typeBtn.on('click', function(e){

				e.preventDefault();
				_this.typeBtn.removeClass('btn-success');
				$(this).addClass("btn-success");
				if($(this).data('field') == 'text'){
					$("#text").slideDown();
					$("#file").slideUp();
					_this.form.removeClass('data_type_file');					
					_this.form.addClass('data_type_text');					
				}else if($(this).data('field') == 'file'){
					$("#text").slideUp();
					$("#file").slideDown();
					_this.form.removeClass('data_type_text');	
					_this.form.addClass('data_type_file');	
				}


			})
		},

		submitForm: function(){
			_this.form.on("submit", function(e){

				e.preventDefault();

				if(_this.form.hasClass('data_type_text')){

					var $keyword = $("#key_word").val();
					var $text =$("#text_pre_encryption").val();

					$.ajax({
						type:"POST",
						url: "/wp-admin/admin-ajax.php",
						data: {
							action: "action_encrypt",
							keyword: $keyword,
							text: $text
						},
						success:function(response){
							_this.result.val(response);
						}
					});

				}

				if(_this.form.hasClass('data_type_file')){

					var $keyword = $("#key_word").val();
					var $fd = new FormData();
					var $myfile = $('#file_pre_encryption')[0].files[0];
					$fd.append('file', $myfile);
					$fd.append("keyword", $keyword);  
   					$fd.append('action', 'action_encrypt');  
					console.log('file_data', $fd);
					 

					$.ajax({
						type:"POST",
						url: "/wp-admin/admin-ajax.php",
						data: $fd,
						contentType: false,
        				processData: false,
						success:function(response){
							// _this.result.val(response);
						}
					});

				}

			});

		}

	}

	_this.chooseType();
	_this.submitForm();
});