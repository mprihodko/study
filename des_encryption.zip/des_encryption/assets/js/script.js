jQuery(document).ready(function($){
	
	var _this = {


		typeBtn: $(".typetBtn"),
		form: $("#encryption_form"),


		chooseType: function(){
			_this.typeBtn.on('click', function(e){

				e.preventDefault();
				_this.typeBtn.removeClass('btn-success');
				$(this).addClass("btn-success");
				if($(this).data('field') == 'text'){
					$("#text").slideDown();
					$("#file").slideUp();					
				}else if($(this).data('field') == 'file'){
					$("#text").slideUp();
					$("#file").slideDown();
				}


			})
		},

		submitForm: function(){
			_this.form.on("submit", function(e){

				e.preventDefault();

				var $keyword = $("#key_word").val();
				var $text =$("#text_pre_encryption").val();

				$.ajax({
					type:"GET",
					url: "/wp-admin/admin-ajax.php",
					data: {
						action: "action_encrypt",
						keyword: $keyword,
						text: $text
					},
					success:function(response){
						console.log('response', response);
					}
				});

			});

		}

	}

	_this.chooseType();
	_this.submitForm();
});