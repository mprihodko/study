<?php 
// silence is golden