<?php 

/**
 * @package DES Encryption
 * @version 1.0
 */
/*
Plugin Name: DES Encryption
Author: Maksim Prihodko
Version: 1.0
*/

ini_set('error_reporting', E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);



class DES_Main{


	/**
	* @package DES Encryption
 	* @version 1.0
 	* @return Plugin init
 	**/



 	/**
	* @package DES Encryption
 	* @version 1.0
 	* @param plugins path
 	* @var array
 	**/

 	protected $path;


 	/**
	* @package DES Encryption
 	* @version 1.0
 	* @param plugins path
 	* @var array
 	**/

 	public $error;



 	public function __construct(){

 		$this->path['uri']=plugin_dir_url(__FILE__);
 		$this->path['dir']=plugin_dir_path(__FILE__); 	
 		add_action('wp_enqueue_scripts', array($this, 'add_scripts'));

 		add_action("wp_ajax_action_encrypt", array($this, "action_encrypt"));
 		add_action("wp_ajax_nopriv_action_encrypt", array($this, "action_encrypt"));

 		add_shortcode('encryption_form', array($this, 'register_shortCode'));
 	}


 	public function register_shortCode($atts){
 		if($atts && is_array($atts))
 			extract($atts);

 		if(file_exists($this->path['dir'].'/view/form.phtml')){
 			include $this->path['dir'].'/view/form.phtml';
 		}else{
 			$this->error = "File: ". $this->path['dir'] ."/view/form.phtml Doesn't Exists";
 		}

 	}

 	public function add_scripts(){

 		wp_enqueue_script('ds-scripts', $this->path['uri']."/assets/js/script.js", array('jquery'), time(), true);

 		wp_enqueue_style('ds-styles', $this->path['uri']."/assets/css/style.css");

 	}

 	public function action_encrypt(){


 		if(!$_POST)
 			wp_die();

 		if(isset($_POST['keyword']) && isset($_POST['text'])){
 			/*encrypt*/

 			/*define iv bite size*/
 			$iv_size = mcrypt_get_iv_size(MCRYPT_DES, MCRYPT_MODE_CFB);
 			/*define iv init*/
   			$iv = mcrypt_create_iv($iv_size, MCRYPT_RAND);
 			$data = $iv.@mcrypt_encrypt(MCRYPT_DES, $_POST['keyword'], $_POST['text'], MCRYPT_MODE_CFB, $iv);
 			$data_to_base64 = base64_encode($data);
 			// echo $data;
 			echo $data_to_base64; 

 			/*decrypt*/
 			$data_dec = base64_decode($data_to_base64);
 			$iv_dec = substr($data_dec, 0, $iv_size);
 			$data_dec = substr($data_dec, $iv_size);
 			// echo mcrypt_decrypt(MCRYPT_DES, $_POST['keyword'], $data_dec, MCRYPT_MODE_CFB, $iv_dec);
 		}
 		if(isset($_POST['keyword']) && isset($_FILES['file'])){
 			$iv_size = mcrypt_get_iv_size(MCRYPT_DES, MCRYPT_MODE_CFB);
 			$iv = mcrypt_create_iv($iv_size, MCRYPT_RAND);
 			$file = file_get_contents($_FILES['file']['tmp_name']);
 			$data = $iv.@mcrypt_encrypt(MCRYPT_DES, $_POST['keyword'], $file, MCRYPT_MODE_CFB, $iv);
 			$data_to_base64 = base64_encode($data);

 			// $image = base64_encode(file_get_contents($_FILES['file']['tmp_name']));
 			$data_dec = base64_decode($data_to_base64);
 			$iv_dec = substr($data_dec, 0, $iv_size);
 			$data_dec = substr($data_dec, $iv_size);
 			$end_dec = @mcrypt_decrypt(MCRYPT_DES, $_POST['keyword'], $data_dec, MCRYPT_MODE_CFB, $iv_dec);
 			echo '<img src="data:'.$_FILES['file']['type'].';base64,'.base64_encode($end_dec).'">';
 		}
 		wp_die();
 	}


}
new DES_Main;


